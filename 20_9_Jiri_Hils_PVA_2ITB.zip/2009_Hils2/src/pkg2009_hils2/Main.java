package pkg2009_hils2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
    }
    
    public int[] hasNum(int[] nums, int num){
        ArrayList<Integer> arl = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Zadejte 4 hodnoty:");
        arl.add(sc.nextInt());
        arl.add(sc.nextInt());
        arl.add(sc.nextInt());
        arl.add(sc.nextInt());
        return null;
    }
}
