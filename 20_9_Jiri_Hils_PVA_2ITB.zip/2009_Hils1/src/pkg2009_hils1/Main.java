package pkg2009_hils1;

import java.util.*;

public class Main {
    public Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

    }
    public int[] dejVLevo(int[] nums, int num){

        System.out.println("[3,4,8,2]");
        System.out.println("[4,8,2,3]");
        System.out.println("[8,2,3,4]");
    return null;
    }
    
}
