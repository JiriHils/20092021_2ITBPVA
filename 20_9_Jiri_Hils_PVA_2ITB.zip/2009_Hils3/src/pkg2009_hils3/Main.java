
package pkg2009_hils3;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    }
    
    public int[] sum(int[] nums){
       Scanner sc = new Scanner(System.in);
        System.out.println("Zadejte 3 hodnoty:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        System.out.println(a+b+c);
        return null;      
    }
}
